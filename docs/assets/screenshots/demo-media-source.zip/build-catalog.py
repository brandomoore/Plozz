#!/usr/bin/env python3
"""Create original procedural media for real Plozz screenshot captures.

No stock images, movie artwork, online metadata, recordings or external fonts.
The geometry, palettes, descriptions and subtitles are authored in this file.
"""
import argparse
import hashlib
import json
import math
import shutil
import subprocess
import cairosvg
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
from xml.sax.saxutils import escape

CATALOGUE = [
    ("Orbital Drift", "A quiet journey through imaginary moons and distant rings.", "space", ["#090f2c", "#334f81", "#f7b783", "#9fcbd2"]),
    ("Tidal Light", "Layers of blue water follow the changing light across an imagined coast.", "water", ["#041c2a", "#1b6b83", "#93d6ce", "#e4ebc7"]),
    ("Amber Horizon", "A slow passage across dunes shaped by light and shadow.", "dunes", ["#291224", "#975751", "#e7a664", "#f4d4a0"]),
    ("Quiet Geometry", "An original study of circles, reflections and shifting perspective.", "arches", ["#152e31", "#326c63", "#b0c09a", "#edd9ab"]),
    ("Signal Garden", "An imaginary landscape grows from repeated lines and simple forms.", "forest", ["#071e25", "#23656a", "#79b6a0", "#d9d897"]),
    ("The Blue Interval", "Cloud-like forms move through a landscape made entirely from geometry.", "dunes", ["#16192e", "#474878", "#8997b8", "#dfc4bb"]),
    ("Dawn Passage", "A narrow trail winds between layers of an imagined mountain range.", "ridges", ["#192432", "#5b6e80", "#d2a17a", "#f5dec0"]),
    ("Lantern Coast", "Small islands gather beneath a bright coastal sky.", "islands", ["#123132", "#337b78", "#a1c2ab", "#f0cb85"]),
    ("Pale Meridian", "A map of distant points traces a journey across an imaginary sky.", "constellation", ["#16203b", "#384b77", "#b0c7df", "#e8dccc"]),
    ("Glass Harbor", "Translucent towers frame the reflections of a fictional harbor.", "city", ["#10252e", "#3c6b80", "#a3b9bc", "#edc39b"]),
    ("Copper Rain", "Slender lines of light descend over a copper-colored landscape.", "rain", ["#2c1b22", "#85504a", "#c3876b", "#f0ce99"]),
    ("Winter Atlas", "Pale ridgelines unfold across a quiet geometric world.", "ridges", ["#172435", "#647f96", "#bcced0", "#f0e9d8"]),
    ("The Soft Current", "Curved ribbons drift through a calm, imagined sea.", "water", ["#162632", "#3b6b7b", "#8fb7bb", "#e7d7b7"]),
    ("Night Orchard", "An orchard of simple silhouettes changes under a midnight sky.", "forest", ["#182136", "#33486c", "#7d9bac", "#e4caa3"]),
    ("A Wider Sky", "Sweeping arcs cross an open sky of stars and imagined moons.", "space", ["#191d36", "#535c83", "#b5a8c5", "#e7c6a4"]),
    ("Ochre Fields", "Warm planes and distant contours form an abstract open landscape.", "dunes", ["#322821", "#8e7150", "#c4ab76", "#f4dfb0"]),
    ("Cobalt Crossing", "An archway opens onto a landscape made from repeating blue forms.", "arches", ["#111f40", "#345b91", "#91b5c6", "#e3d6b4"]),
    ("Stillwater Lines", "Reflections repeat across a lake that exists only in geometry.", "water", ["#142d2b", "#497b68", "#a7bb94", "#efe4bd"]),
    ("Prism Season", "Angled planes divide the light into a changing abstract study.", "prism", ["#28243c", "#6c6383", "#c0a4b1", "#efd6bd"]),
    ("Blue Hour Station", "A fictional skyline appears between the last light and the first stars.", "city", ["#172232", "#4b637d", "#a0b2bd", "#ebc693"]),
    ("The Long Arc", "A ring crosses a distant moon in a slow geometric orbit.", "space", ["#14232b", "#3f6a75", "#93b4b7", "#efd0a4"]),
    ("Silver Estuary", "Pale channels and small islands meet beneath a quiet horizon.", "islands", ["#192b33", "#5b7a86", "#b1c5c2", "#e9debf"]),
    ("Contour Season", "Layered peaks form a visual notebook of an imaginary terrain.", "ridges", ["#2e2930", "#806d78", "#bfaaab", "#ecdac3"]),
    ("Green Interval", "An abstract forest pauses between shadow and afternoon light.", "forest", ["#102929", "#386b5c", "#87ad83", "#e2d9a2"]),
    ("After the Tide", "Bands of light recede over a shoreline made from curves.", "water", ["#122b3b", "#426e8d", "#94b6c7", "#dfd9b4"]),
    ("The Last Contour", "A final ridgeline separates a warm sky from a cool valley.", "ridges", ["#252139", "#64618d", "#a7a5c2", "#edcfb3"]),
    ("Rose Compass", "A constellation of small lights sketches an imaginary route.", "constellation", ["#331e32", "#83526e", "#c59eac", "#f2d4b5"]),
    ("Paper Islands", "Flat silhouettes float across a wide, imagined archipelago.", "islands", ["#17313c", "#457d8b", "#97b8b2", "#ebd59c"]),
    ("Moonlit Index", "Points and paths catalogue a sky of original geometric forms.", "constellation", ["#181c31", "#464a73", "#9da9c5", "#e8d9b5"]),
    ("Northern Rooms", "Repeated arches create a study of shelter, perspective and cool light.", "arches", ["#203035", "#597b7a", "#b0c1b0", "#e4d5b6"]),
    ("Violet Distance", "Faraway dunes and a pale disc mark an imagined evening.", "dunes", ["#281c3e", "#665082", "#b49cc2", "#edcdb6"]),
    ("Small Weather", "Fine strokes and soft circles describe weather without a real location.", "rain", ["#202d36", "#526f86", "#a8bec8", "#eadbbb"]),
    ("Beyond the Steps", "Light travels through a sequence of original architectural shapes.", "arches", ["#30252b", "#896b66", "#bca69b", "#f0d6ac"]),
    ("Golden Transit", "An imagined city moves between warm planes of light.", "city", ["#2b2631", "#786576", "#bda392", "#efd29a"]),
    ("Quiet Spectrum", "Simple facets become a calm study of color and reflected light.", "prism", ["#1b2b34", "#4c7886", "#a6bdc0", "#e7cdb7"]),
    ("Low Sun Archive", "Original silhouettes form a small archive of changing horizons.", "dunes", ["#322522", "#97674f", "#d3a279", "#f3deb4"]),
    ("Sea of Angles", "Geometric planes form an ocean without borrowed footage.", "prism", ["#102c35", "#307b8c", "#88bfc0", "#e0dba8"]),
]


def artwork(kind, colors, variant=0):
    bg, middle, light, highlight = colors
    shapes = []
    if kind == "space":
        for i in range(150):
            x, y = (i * 317 + 91) % 1920, (i * 157 + 27) % 1080
            shapes.append(f'<circle cx="{x}" cy="{y}" r="{1 + i % 3}" fill="{highlight}" opacity="{.18 + (i % 7) * .07}"/>')
        shapes.append(f'<circle cx="1210" cy="480" r="300" fill="url(#orb)"/>')
        shapes.append(f'<ellipse cx="1210" cy="505" rx="540" ry="115" transform="rotate(-24 1210 505)" fill="none" stroke="{light}" stroke-width="30" opacity=".65"/>')
        shapes.append(f'<circle cx="700" cy="235" r="70" fill="{highlight}" opacity=".65"/>')
    elif kind in ("water", "dunes"):
        shapes.append(f'<circle cx="1250" cy="300" r="150" fill="{highlight}" opacity=".9"/>')
        for i in range(9):
            points = []
            for x in range(-20, 1961, 20):
                y = 430 + i * 84 + math.sin(x / (230 + i * 20) + i * .8 + variant) * (95 if kind == "dunes" else 35)
                points.append(f"{x},{y:.1f}")
            tone = colors[1 + i % 3]
            shapes.append(f'<path d="M {" L ".join(points)} L 1940,1100 L -20,1100 Z" fill="{tone}" opacity="{.38 + i * .045}"/>')
    elif kind == "arches":
        for i in range(10):
            x = 160 + i * 155
            shapes.append(f'<path d="M {x},1100 V 560 A 210 280 0 0 1 {x + 420},560 V 1100" fill="none" stroke="{colors[1 + i % 3]}" stroke-width="48" opacity=".7"/>')
        shapes.append(f'<circle cx="1350" cy="260" r="90" fill="{highlight}"/>')
    elif kind == "forest":
        shapes.append(f'<circle cx="1200" cy="340" r="230" fill="{highlight}" opacity=".85"/>')
        for i in range(20):
            x = -60 + i * 112
            y = 400 + 160 * math.sin(i * 1.1)
            shapes.append(f'<path d="M{x},{y} L{x - 150},1080 H{x + 170} Z" fill="{colors[i % 3]}" opacity=".8"/>')
    elif kind == "ridges":
        shapes.append(f'<circle cx="{1110+variant%4*70}" cy="270" r="138" fill="{highlight}"/>')
        for layer in range(5):
            y=550+layer*150
            points=[f"{x},{y-120-math.sin(x/190+layer+variant)*130:.1f}" for x in range(-80,2001,160)]
            shapes.append(f'<path d="M -80,1100 L {" L ".join(points)} L 2000,1100 Z" fill="{colors[layer%3]}" opacity=".86"/>')
    elif kind == "islands":
        shapes.append(f'<circle cx="1270" cy="270" r="145" fill="{highlight}"/>')
        for i in range(7):
            shapes.append(f'<ellipse cx="{260+i*210}" cy="{560+i*63}" rx="{150+i*30}" ry="{28+i*5}" fill="{colors[1+i%3]}" opacity=".8"/>')
    elif kind == "city":
        shapes.append(f'<circle cx="1280" cy="320" r="185" fill="{highlight}"/>')
        for i in range(15):
            y=390+(i*131+variant*39)%360
            shapes.append(f'<rect x="{i*140-50}" y="{y}" width="115" height="{1080-y}" fill="{colors[i%3]}" opacity=".86"/>')
            shapes.append(f'<path d="M{i*140-36},{y+18} V1060" stroke="{light}" opacity=".35" stroke-width="4"/>')
    elif kind == "rain":
        shapes.append(f'<circle cx="1260" cy="390" r="255" fill="{light}" opacity=".65"/>')
        for i in range(60):
            x=(i*147)%2040-60;y=(i*113+variant*31)%950
            shapes.append(f'<path d="M{x},{y} l-75,180" stroke="{highlight}" stroke-width="{2+i%6}" opacity="{.1+(i%5)*.08}"/>')
    elif kind == "constellation":
        points=[((i*347+200)%1720+100,(i*193+variant*51)%810+100) for i in range(24)]
        shapes.append(f'<polyline points="{" ".join(f"{x},{y}" for x,y in points)}" fill="none" stroke="{light}" stroke-width="3" opacity=".35"/>')
        for i,(x,y) in enumerate(points):
            shapes.append(f'<circle cx="{x}" cy="{y}" r="{3+i%8}" fill="{highlight}"/>')
    elif kind == "prism":
        for i in range(13):
            x=-400+i*200
            shapes.append(f'<path d="M{x},1080 L{x+660},0 L{x+910},0 L{x+100},1080 Z" fill="{colors[1+i%3]}" opacity=".55"/>')
    else:
        raise ValueError(f"Unknown artwork kind: {kind}")
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">
<defs>
<linearGradient id="sky" x2=".8" y2="1"><stop stop-color="{bg}"/><stop offset="1" stop-color="{middle}"/></linearGradient>
<radialGradient id="orb" cx=".3" cy=".25"><stop stop-color="{highlight}"/><stop offset=".5" stop-color="{light}"/><stop offset="1" stop-color="{middle}"/></radialGradient>
</defs><rect width="1920" height="1080" fill="url(#sky)"/>{''.join(shapes)}
</svg>'''


def run(*args):
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--posters-only", action="store_true")
    args = parser.parse_args()
    root = args.out.resolve()
    root.mkdir(parents=True, exist_ok=True)
    font_source = Path(__file__).resolve().parent / "assets/manrope.woff2"
    font_file = root / ".poster-font.ttf"
    font = TTFont(font_source)
    font.flavor = None
    font.save(font_file)
    for index, (title, plot, kind, colors) in enumerate(CATALOGUE):
        series = False
        minutes = [3, 5, 8, 12][index % 4]
        folder = root / ("Shows" if series else "Movies") / title
        folder.mkdir(parents=True, exist_ok=True)
        svg = folder / "artwork.svg"
        svg.write_text(artwork(kind, colors, index), encoding="utf-8")
        raster = folder / ".artwork.png"
        cairosvg.svg2png(url=str(svg), write_to=str(raster))
        run("magick", str(raster), "-alpha", "off", str(folder / "fanart.jpg"))
        raster.unlink()
        run("magick", str(folder / "fanart.jpg"), "-gravity", "East", "-crop", "720x1080+180+0", "+repage", str(folder / "poster.jpg"))
        poster = Image.open(folder / "poster.jpg").convert("RGBA")
        shade = Image.new("RGBA", poster.size)
        draw = ImageDraw.Draw(shade)
        for y in range(1080):
            draw.line((0, y, 720, y), fill=(5, 10, 22, int(230 * max(0, (y - 420) / 660))))
        poster = Image.alpha_composite(poster, shade)
        draw = ImageDraw.Draw(poster)
        title_font = ImageFont.truetype(str(font_file), 76)
        title_font.set_variation_by_axes([700])
        small_font = ImageFont.truetype(str(font_file), 18)
        draw.text((48, 48), "PLOZZ DEMO", font=small_font, fill="#ffffff")
        words, lines = title.upper().split(), []
        for word in words:
            if lines and draw.textlength(lines[-1] + " " + word, font=title_font) <= 620:
                lines[-1] += " " + word
            else:
                lines.append(word)
        for line_index, line in enumerate(lines):
            draw.text((44, 940 - len(lines) * 88 + line_index * 88), line, font=title_font, fill="#ffffff")
        draw.text((48, 1010), "AN ORIGINAL VISUAL STUDY", font=small_font, fill="#d4dfeb")
        poster.convert("RGB").save(folder / "poster.jpg", quality=96)
        if args.posters_only:
            continue
        root_tag = "tvshow" if series else "movie"
        (folder / ("tvshow.nfo" if series else "movie.nfo")).write_text(
            f"<{root_tag}><title>{escape(title)}</title><year>2026</year>"
            f"<plot>{escape(plot)}</plot><genre>Visual studies</genre><studio>Plozz Demo</studio>"
            f"<runtime>{minutes}</runtime></{root_tag}>", encoding="utf-8")
        # A short original animated clip is repeated with stream copy, not synthesized UI.
        base = folder / ".motion.mp4"
        run("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-loop", "1",
            "-i", str(folder / "fanart.jpg"), "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
            "-vf", "scale=2000:-1,crop=1920:1080:x='40+35*sin(t/6)':y=20,format=yuv420p",
            "-t", "12", "-r", "24", "-c:v", "libx264", "-preset", "fast", "-crf", "19",
            "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", str(base))
        for episode in range(1, 5) if series else [0]:
            target = folder / (f"Season 01/{title} - S01E{episode:02d} - Study {episode}.mp4" if series else f"{title} (2026).mp4")
            target.parent.mkdir(exist_ok=True)
            run("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-stream_loop", str(minutes*5-1),
                "-i", str(base), "-c", "copy", "-t", str(minutes*60), "-movflags", "+faststart", str(target))
            subtitle = "A new shape appears on the horizon.\nThe light moves, and the landscape changes."
            target.with_suffix(".en.srt").write_text(f"1\n00:00:00,000 --> 00:{minutes:02d}:00,000\n" + subtitle + "\n", encoding="utf-8")
            if series:
                target.with_suffix(".nfo").write_text(
                    f"<episodedetails><title>Study {episode}: {['First light','A new perspective','Quiet motion','The long view'][episode-1]}</title>"
                    f"<season>1</season><episode>{episode}</episode><plot>{escape(plot)}</plot>"
                    f"<aired>2026-01-0{episode}</aired><runtime>3</runtime></episodedetails>", encoding="utf-8")
                shutil.copyfile(folder / "fanart.jpg", target.with_name(target.stem + "-thumb.jpg"))
        base.unlink()
        print(f"Created original {'series' if series else 'film'}: {title}", flush=True)
    font_file.unlink()
    inventory = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "provenance.json":
            inventory.append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    (root / "provenance.json").write_text(json.dumps({
        "source": "build-catalog.py",
        "kind": "Original procedural vector artwork, animated media, metadata and subtitles",
        "posterTypeface": "Manrope, SIL Open Font License 1.1; see public/fonts/OFL.txt",
        "thirdPartyMedia": False, "onlineMetadata": False, "files": inventory,
    }, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
